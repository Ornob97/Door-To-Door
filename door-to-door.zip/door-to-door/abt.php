<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/logo.png" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>About Us</p>
	<link rel="stylesheet" type="text/css" href="css/s1.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="index.php">Main Screen</a></li>
				<li><a href="signup.php">Sign Up</a></li>
				<li><a href="login.php">Login</a></li>
				<li><a href="contect.php">Contact</a></li>
				

			</ul>
		</nav>
	</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>

	<!--About-->
	<section id="about">
		<div class="title-text">
  <div class=""align="center">
    <img src="images/vision.png" ALT="some text" WIDTH=80 HEIGHT=60>
      <ul style="list-style:none;">
          <p><a href=""><u>Our Vision</u></a></p>
        </ul>
<h2>Door To Door is a website where you can buy and sell almost everything. The best deals are often done with people who live in your own city or on your own street, so on Door To Door, it's easy to buy and sell locally.</h2>
  </div>
  <br>
  <div class=""align="center">
    <img src="images/target.png" ALT="some text" WIDTH=80 HEIGHT=60>
    <ul style="list-style:none;">
    <p><a href=""><u>Our Goal</u></a><p>
    <h2>Biggest variety-We offer million of products at a great value for our customer.
Best prices-We provide great value by offering competitive prices on all our products.
Ease and speed-Visit our website for a smooth shopping experience.
Fast Delivery- We aim to please our customers with fast delivery and an easy tracking system.</h2>
  </ul>
  </div>
  <br>
  <div class=""align="center">
    <img src="images/mission.png" ALT="some text" WIDTH=80 HEIGHT=60>
    <ul style="list-style:none;">
  <p><a href=""><u>Our Mission</u></a></p>
  <h2>Our mission is to make the Door To Door website dedicated to making online shopping fast, reliable, and convenient for our valued stakeholders, clients, and consumers-transforming it into a true and trustworthy doorstep service for the users aligning with the economic development of the country.</h2>
</ul>
  </div>

      <br><br>
</div>
	</section>

	
	<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
