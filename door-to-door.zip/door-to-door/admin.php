<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<div class="banner-text">
		<h1>Door To Door</h1>

		<video width="1150px" height="400px" controls><source src="videos/yt1s.com - Explainer video for courier service_360p.mp4" type="video/mp4"></video>
		<br><br>
		<p>Sell Post</p>
		
	<link rel="stylesheet" type="text/css" href="css/s88.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<br>
<br>
<table id="customers" style="margin: 0px auto;">
  <tr>
		<th>ID</th>
    <th>Name</th>
    <th>Date</th>
    <th>Email</th>
		<th>Mobile no</th>
		<th>Product Information</th>
		<th>Product ID</th>
		<th>Price</th>
		<th>Address</th>

  </tr>
	<?php
$q=$db->query("SELECT * FROM post_for_sell");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
	?>
	<tr>
		<?php
        $d=$p->date;
        $current=date("Y/m/d");
        $month=((strtotime($current) - strtotime($d))/60/60/24)/30;
    if($month<0.0)
    {
    	?>
      <td><font color="red"><?= $p->id; ?></font></td>
      <td><font color="red"><?= $p->name; ?></font></td>
      <td><font color="red"><?= $p->date; ?></font></td>
  	  <td><font color="red"><?= $p->email; ?></font></td>
  	  <td><font color="red"><?= $p->mno; ?></font></td>
  	  <td><font color="red"><?= $p->proinfo; ?></font></td>
        <td><font color="red"><?= $p->proid; ?></font></td>
        <td><font color="red"><?= $p->price; ?></font></td>
    	  <td><font color="red"><?= $p->address; ?></font></td>
	<?php
}
else {
      ?>
      <td><?= $p->id; ?></td>
      <td><?= $p->name; ?></td>
      <td><?= $p->date; ?></td>
  	  <td><?= $p->email; ?></td>
  	  <td><?= $p->mno; ?></td>
  	  <td><?= $p->proinfo; ?></td>
        <td><?= $p->proid; ?></td>
        <td><?= $p->price; ?></td>
    	  <td><?= $p->address; ?></td>
  <?php
    }
	 ?>
	</tr>
	<?php
}?>

</table>

	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				
				<li><a href="screen.php">User</a></li>
				<li><a href="admin_login.php">Admin</a></li>
				
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
