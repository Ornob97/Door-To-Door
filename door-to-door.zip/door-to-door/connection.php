<?php
$db=new PDO('mysql:host=localhost;dbname=door_to_door','root','');
if($db)
{
	echo "Connect";
}
else
{
	echo "Not Connect";
}
?>