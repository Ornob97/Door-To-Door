<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/cl.jpg" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>About Us</p>
	<link rel="stylesheet" type="text/css" href="css/s2.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>

	<div class="banner-btn">
		<br><br>

	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="index.php">Main Screen</a></li>
				<li><a href="abt.php">About Us</a></li>
				<li><a href="signup.php">Sign Up</a></li>
				<li><a href="login.php">Login</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>

	<!--Contact-->
	<section id="about">
		<div class="title-text">
  <div class=""align="center">
    <img src="images/O.jpeg" ALT="some text" WIDTH=90 HEIGHT=100>
<h2 style="color:white;">Name: Tanvir mahim Ornob</h2>
<h2 style="color:white;">Email: tanvirmahim@yahoo.com</h2>
<h2 style="color:white;">Facebook ID: Tanvir Mahim Ornob</h2>
  </div>
  
  <br>
  <div class=""align="center">
    <img src="images/B.jpeg" ALT="some text" WIDTH=120 HEIGHT=100>
<h2 style="color:white;">Name: Mohammad Mahabub a Mostafa Badhan</h2>
<h2 style="color:white;">Email: mohammad.badhan@northsouth.edu</h2>
<h2 style="color:white;">Facebook ID: Badhon Mostofa</h2>
  </div>

      <br><br>
</div>
	</section>

	
	<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
