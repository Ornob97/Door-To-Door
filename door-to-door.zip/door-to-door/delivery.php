<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/logo.png" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Hand over products from one place to another</p>
	<link rel="stylesheet" type="text/css" href="css/s88.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<div class="banner-btn">
		<a href="deliveryman.php">Be a Delivery Man</a>
		<a href="proceed.php">Proceed to Delivery</a>

		<br><br>
		<p>Deliveryman Information</p>
<br>
<table id="customers" style="margin: 0px auto;">
  <tr>
		<th>ID</th>
    <th>Name</th>
    <th>Date</th>
    <th>Email</th>
		<th>Mobile no</th>
		<th>Preferable time</th>
		<th>Range 1</th>
		<th>Range 2</th>

  </tr>
	<?php
$q=$db->query("SELECT * FROM delivery");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
	?>
	<tr>
      <td><font color="black"><?= $p->id; ?></font></td>
      <td><font color="black"><?= $p->name; ?></font></td>
      <td><font color="black"><?= $p->date; ?></font></td>
  	  <td><font color="black"><?= $p->email; ?></font></td>
  	  <td><font color="black"><?= $p->mno; ?></font></td>
  	  <td><font color="black"><?= $p->time_24_Hour_system; ?></font></td>
      <td><font color="black"><?= $p->range1; ?></font></td>
      <td><font color="black"><?= $p->range2; ?></font></td>
  </tr>
	<?php
}
	 ?>

</table>
		


	</div>
	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="screen.php">User Home</a></li>
				
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
