<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Deliveryman Registration</p>
	<link rel="stylesheet" type="text/css" href="css/s8.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	
      <br><br><br>
      <center>
      	
      	<div id="form">
        <form action="" method="post">
        <table>

    <label for="first" style ="text-decoration: none; color:black;" >Name:</label>
	<input id="first" type="text" name="name" placeholder="Name"  autofocus required />

	<br><br><br><br>

	<label style="text-decoration: none;  color:black;">Date:</label>
	<input id="date" name="date" type="date" value="2021-12-27">
		 

	<br><br><br><br>

	<label for="first" style="text-decoration: none;  color:black;" >Email:</label>
	<input id="first" type="text" name="email" placeholder="Email"  autofocus required />

	<br><br><br><br>

	<label for="phone" style="text-decoration: none;  color:black;" >Phone Number:</label>
	<input id="phone" type="tel" name="mno"placeholder="+8801********" required />

	<br><br><br>

	<label for="first" style="text-decoration: none;  color:black;" >Preferable Time:</label>
	<input id="first" type="text" name="time" placeholder="12 am - 12 pm "  autofocus required />

	<br><br><br><br>

	<label for="first" style="text-decoration: none;  color:white;" >Address</label>
	<input id="first" type="text" name="address" placeholder="Address"  autofocus required />
<br><br>
<label for="first" style="text-decoration: none;  color:white;" >Range 1</label>
	<input id="first" type="text" name="range1" placeholder="Range 1"  autofocus required />
<br><br>
<label for="first" style="text-decoration: none;  color:white;" >Range 2</label>
	<input id="first" type="text" name="range2" placeholder="Range 2"  autofocus required />
<br><br>

	 <tr>
            <td><input type="submit" name="sub" value="Submit"></td>
          </tr>

      </table>
  </form>


</div>
 <?php
    if(isset($_POST['sub'])){
        $name=$_POST['name'];
        $date=$_POST['date'];
        $email=$_POST['email'];
        $mno=$_POST['mno'];
        $time=$_POST['time'];
        $address=$_POST['address'];
        $range1=$_POST['range1'];
        $range2=$_POST['range2'];
				
 $q=$db->prepare("INSERT INTO delivery(name,date,email,mno,time,address,range1,range2) VALUES (:name, :date, :email, :mno, :time,:address,:range1,:range2)");

        $q->bindValue('name',$name);
        $q->bindValue('date',$date);
        $q->bindValue('email',$email);
        $q->bindValue('mno',$mno);
        $q->bindValue('time',$time);
        $q->bindValue('address',$address);
        $q->bindValue('range1',$range1);
        $q->bindValue('range2',$range2);
 

        if($q->execute()){
	          echo "<script>alert('Registration Succesfull!')</script>";
              }
        else{
            echo "<script>alert('Registration Failed!')</script>";
        }
    }

    ?>
      </div></center>
    </div>

	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="admin.php">Home</a></li>
				
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
