<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/logo.png" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Hand over products from one place to another</p>
	<link rel="stylesheet" type="text/css" href="css/s00.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<div class="banner-btn">
		<a href="login.php">Login</a>
		<a href="signup.php">Sign Up</a>
	</div>
	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="admin_login.php">Admin Login</a></li>
				<li><a href="abt.php">About Us</a></li>
				<li><a href="contect.php">Contact</a></li>
				<li><a href="signup.php">Sign up</a></li>
				
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
