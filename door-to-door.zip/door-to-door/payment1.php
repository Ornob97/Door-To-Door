<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="hero">
		<div class="form-box">
			<center><div id="form">
        <form action="" method="post">
        <table>
        	<br>
        	<p>CARD CHECKOUT</p>
        	<div class="social-icons">
			<img src="bk.png">
			<img src="mc.png">
			<img src="visa.png">
			<img src="nogod.jpg">
        	<br><br>

 <form class="input-group">
	<input id="first" type="text" class="input-field" name="cno" placeholder="Card Number"  autofocus required />

	<br><br>

	<input id="date" name="date" class="input-field" type="date" value="2021-12-27">
		 

	<br><br>

	<input id="first" type="text" class="input-field" name="cvv" placeholder="CVV No:"  autofocus required />

	<br><br>

	<input id="first" type="text" class="input-field" name="hname" placeholder="Card Holder Name"  autofocus required />

	
	<br>
	 
	 <tr>
            <td><input type="submit" name="sub" class="submit-btn" value="Submit"></td>
          </tr>
      </form>
      </table>
  </form>
		</div>
	</div>
	<?php
    if(isset($_POST['sub'])){
        $cno=$_POST['cno'];
        $date=$_POST['date'];
        $cvv=$_POST['cvv'];
        $hname=$_POST['hname'];
       
				
 $q=$db->prepare("INSERT INTO payment(cno,date,cvv,hname) VALUES (:cno, :date, :cvv, :hname)");

        $q->bindValue('cno',$cno);
        $q->bindValue('date',$date);
        $q->bindValue('cvv',$cvv);
        $q->bindValue('hname',$hname);
       
       

      if($q->execute()){

           $_SESSION['un']=$un;
           header("Location:otp.php");

          
         }
            else
            {
                   $_SESSION['un']=$un;
           header("Location:otp.php");
            } 
        }
           ?>
      </div></center>
    </div>
    </div>
	<script>
		var x=document.getElementById("login");
		var y=document.getElementById("register");
		var z=document.getElementById("btn");

		function register(){
			x.style.left="-400px";
			y.style.left="50px";
			z.style.left="110px";
		}
		function login(){
			x.style.left="50px";
			y.style.left="450px";
			z.style.left="0";
		}

	</script>

</body>
</html>