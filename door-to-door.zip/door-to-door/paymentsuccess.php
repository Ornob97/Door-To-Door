<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<link rel="stylesheet" type="text/css" href="otp.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>

	<div class="banner-text">
		<p> <a style="text-decoration: none; font-size: 100px; font-family: 'Kaushan Script', cursive;color:white;"/> Payment Successfull</p>
	<div id="header"><h1><a href='admin.php'style="text-decoration: none; font-size: 30px; font-family: 'Kaushan Script', cursive;color:white;">Skip </a></h1></div>
	<div id="header"><h1><a href='review.php'style="text-decoration: none; font-size: 30px; font-family: 'Kaushan Script', cursive;color:white;">Give Review </a></h1></div>
</body>
</html>
