<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door-to-Door </title>
	<div class="banner-text">
		<h1>Proceed to Delivery</h1>
		
	<link rel="stylesheet" type="text/css" href="css/s8.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<br>
<p align="center">Post for Sell</p>
<br><br>

<table id="customers" style="margin: 0px auto;">
  <tr>
		<th>ID</th>
    <th>Name</th>
    <th>Date</th>
    <th>Email</th>
    <th>Mobile no</th>
    <th>Product Information</th>
    <th>Product ID</th>
    <th>Price</th>
    <th>Address</th>
  </tr>
	<?php
$q=$db->query("SELECT * FROM post_for_sell");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
	?>
  <tr>
    <?php
        $d=$p->date;
        $current=date("Y/m/d");
        $month=((strtotime($current) - strtotime($d))/60/60/24)/30;
    if($month>=0.0) {
      ?>
      <td><?= $p->id; ?></td>
      <td><?= $p->name; ?></td>
      <td><?= $p->date; ?></td>
      <td><?= $p->email; ?></td>
      <td><?= $p->mno; ?></td>
      <td><?= $p->proinfo; ?></td>
      <td><?= $p->proid; ?></td>
      <td><?= $p->price; ?></td>
      <td><?= $p->address; ?></td>
       <?php
    }
    ?>
  </tr>
	<?php
}
	 ?>
</table>

<br>
<p align="center">Deliveryman List</p>
<br><br>

<table id="customers" style="margin: 0px auto;">
 <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Date</th>
    <th>Email</th>
    <th>Mobile no</th>
    <th>Preferable time</th>
    <th>Range 1</th>
    <th>Range 2</th>

  </tr>
<?php
$q=$db->query("SELECT * FROM delivery");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
?>
<tr>
  <td><?= $p->id; ?></td>
  <td><?= $p->name; ?></td>
  <td><?= $p->date; ?></td>
  <td><?= $p->email; ?></td>
  <td><?= $p->mno; ?></td>
  <td><?= $p->time_24_Hour_system; ?></td>
  <td><?= $p->range1; ?></td>
  <td><?= $p->range2; ?></td>
</tr>

<?php
}
 ?>
 </table>

<br></br>

<div class="type">
  <label style="color: #032B41"><u>Proceed a Delivery</u></label>
  <br><br>
<form class="" action="" method="post">
    <label style="font-size:20px;   color:white;">Enter ID of Sell Post:</label>
  <input type="text" name="did" placeholder="ID of Sell Post" style="font-size: 22px; width: 220px; height: 40px; border-radius: 10px;">
  &nbsp;
  <label style="font-size:20px;   color:black;">  Enter ID of Deliveryman:</label>
  <input type="text" name="pid" placeholder="ID of Deliveryman" style="font-size: 22px; width: 220px; height: 40px; border-radius: 10px;">
<br><br><br>
    <input name="sub" type="submit" value="Proceed" style="font-weight:bold;font-size: 12px; width: 90px; height: 35px;border-radius:10px;background-color:#F9054B;font-size:18px;">
<br></br>
  </form>
</div>
<?php

if(isset($_POST['sub']))
{
  $did=$_POST['did'];
  $pid=$_POST['pid'];
  $count=$db->query("SELECT count(*) FROM post_for_sell WHERE id='$did'")->fetchColumn();


$q=$db->query("SELECT date FROM post_for_sell WHERE id='$did'");
$d=$q->fetchColumn();
$current=date("Y/m/d");
$month=((strtotime($current) - strtotime($d))/60/60/24)/30;
if($month<0.0)
{
echo "<script>alert('Sell unsuccessfull')</script>";
}
else {
if(!$count==0){
$qd=$db->query("SELECT * FROM post_for_sell WHERE id='$did'");
$pd=$qd->fetch(PDO::FETCH_OBJ);
$pname=$pd->name;
$daddress=$pd->address;

$qp=$db->query("SELECT * FROM delivery WHERE id='$pid'");
$pp=$qp->fetch(PDO::FETCH_OBJ);
$dname=$pp->name;
$address=$pp->address;
$date=$current;
 if($address==$address){
  $t=$db->prepare("INSERT INTO checkout(pname,dname,address,date) VALUES (:pname,:dname,:address,:date)");
  $t->bindValue('pname',$pname);
  $t->bindValue('dname',$dname);
  $t->bindValue('address',$address);
  $t->bindValue('date',$date);

  $u=$db->prepare("UPDATE `post_for_sell` SET `date`='$date' WHERE id='$did'");

  if($t->execute() && $u->execute()){
      echo "<script>alert('Delivery Successfull')</script>";
  }
  else{
      echo "<script>alert('Delivery Failed!')</script>";
  }
}
else {
  echo "<script>alert('Address not matched!')</script>";
}} 
else
{
   echo "<script>alert('Wrong ID!')</script>";
}
}}
 ?>

<div class="banner-btn">
  <div id="sideNav">
    <nav>
      <ul>
        <li><a href="admin.php">Home</a></li>
        <li><a href="screen.php">Post for Sell</a></li>
        <li><a href="delivery.php">Delivery</a></li>
        <li><a href="payment.php">Payment</a></li>
        <li><a href="refund_list.php">Refund List</a></li>
        <li><a href="review1.php">See Review</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>
    </nav>
  </div>
</div>
  <div id="menuBtn">
    <img src="images/menu.png" id="menu">
  </div>
  

<script>
    var menuBtn=document.getElementById("menuBtn")
    var sideNav=document.getElementById("sideNav")
    var menu=document.getElementById("menu")

        menuBtn.onclick=function(){
          if(sideNav.style.right=="-250px"){
            sideNav.style.right="0";
            }
          else{
            sideNav.style.right="-250px";
            
          }
}
  </script>

</body>
</html>
