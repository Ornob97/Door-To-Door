<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Refund Request</p>
	<link rel="stylesheet" type="text/css" href="css/s17.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	
      <br><br><br>
      <center>
      	
      	<div id="form">
        <form action="" method="post">
        <table>
        	
        	<label for="first" >Product ID:</label>
	<input id="first" type="text" name="proid" placeholder="Product ID"  autofocus required />
<br><br><br><br>
	<label for="first" >Email:</label>
	<input id="first" type="text" name="email" placeholder="Email"  autofocus required />
<br><br><br><br>
	<label style="text-decoration: none;  color:white;"> Order Date:</label>
	<input id="date" name="date1" type="date" value="2021-12-27">
<br><br><br><br>
	<label style="text-decoration: none;  color:white;">Receive Date:</label>
	<input id="date" name="date2" type="date" value="2021-12-27">
<br><br><br><br>
	<label for="first" >Reason Behind Returning Product:</label>
	<input id="first" type="text" name="returning_reason" placeholder="Returning Reason"  autofocus required />
<br><br><br><br>
	<tr>
            <td><input type="submit" name="sub" value="Submit"></td>
          </tr>

	
        </table>
      </form>

       <?php
    if(isset($_POST['sub'])){
        $proid=$_POST['proid'];
        $email=$_POST['email'];
        $date1=$_POST['date1'];
        $date2=$_POST['date2'];
        $returning_reason=$_POST['returning_reason'];
       
				
 $q=$db->prepare("INSERT INTO refund(proid,email,date1,date2,returning_reason) VALUES (:proid,:email,:date1,:date2,:returning_reason)");

        $q->bindValue('proid',$proid);
        $q->bindValue('email',$email);
        $q->bindValue('date1',$date1);
        $q->bindValue('date2',$date2);
        $q->bindValue('returning_reason',$returning_reason);    

      if($q->execute())
            {
              echo "<script>alert('Refund Request Submission Successfull')</script>";
            }
            else
            {
              echo "<script>alert('Refund Request Submission Failed')</script>";
            }
         } 
           ?>
    </div></center>

    <div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
			    
				
				
				<li><a href="deliveryman.php">Delivery</a></li>
				
				<li><a href="review.php">Review</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>
  </body>
