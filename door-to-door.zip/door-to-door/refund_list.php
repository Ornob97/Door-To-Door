<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Refund Request</p>
	<link rel="stylesheet" type="text/css" href="css/s17.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	
      <br><br><br>
      <center>

      	<div class="banner-btn">
		<a href="refund.php">Refund Request</a>
		</div>

		<br><br>
		<p>Refund List</p>
<br>
      	
      	<div id="form">
        <form action="" method="post">
        <table>
        	
        	<table id="customers" style="margin: 0px auto;">
  <tr>
		<th>Product ID</th>
		<th>Email</th>
		<th>Order Date</th>
		<th>Receive Date</th>
		<th>Reason Behind Refund</th>
  </tr>
  <?php
$q=$db->query("SELECT * FROM refund");
while ($p=$q->fetch(PDO::FETCH_OBJ)) {
  ?>
    <tr>
    <td><?= $p->proid; ?></td>
    <td><?= $p->email; ?></td>
    <td><?= $p->date1; ?></td>
    <td><?= $p->date2; ?></td>
    <td><?= $p->returning_reason; ?></td> 
  </tr>
  <?php
}
   ?>

	
        </table>
      </form>
    </div></center>

    <div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
			    
			
				<li><a href="screen.php">Post for Sell</a></li>
				<li><a href="delivery.php">Delivery</a></li>
				
				<li><a href="refund_list.php">Refund List</a></li>
				<li><a href="review1.php">Review</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>
  </body>
