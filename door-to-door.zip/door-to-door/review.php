<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/logo.png" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Review</p>
	<link rel="stylesheet" type="text/css" href="css/s7.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<br>
	
      <br><br><br>
      <center><div id="form">
        <form action="" method="post">
        <table>
         <label for="first" >Full Name:  </label>
	<input id="first" type="text" name="fname" placeholder="Full Name"  autofocus required />

	<br><br><br><br>


    

	<label for="first" >Product ID:   </label>
	<input id="first" type="text" name="proid" placeholder="Product ID"  autofocus required />

	<br><br><br><br>

	<label for="first" >Write review: </label>
	<input id="first" type="text" name="review" style="width: 40px,height: 20px" autofocus required textarea=" review"/>


	<br>
	

	 <tr>
            <td><input type="submit" name="sub" value="Submit"></td>
          </tr>

</div>
    <?php
    if(isset($_POST['sub'])){
        $fname=$_POST['fname'];
        $proid=$_POST['proid'];
        $review=$_POST['review'];
        
        
 $q=$db->prepare("INSERT INTO review(fname,proid,review) VALUES (:fname,:proid,:review)");

        
        $q->bindValue('fname',$fname);
        $q->bindValue('proid',$proid);
        $q->bindValue('review',$review);
        
      
      if($q->execute())
             {

          $_SESSION['un']=$un;
           header("Location:review1.php");
         }
         else
         {
           echo "<script>alert('Wrong User')</script>";
         }
         } 

           ?>
      </div></center>
    </div>

	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="admin.php">Home</a></li>
				
				<li><a href="logout.php">Logout</a></li>

			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>