<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Hand over products from one place to another</p>
		<br><br>
		<p style="color:yellow;"><u>Post Your Product details here</u></p>
	<link rel="stylesheet" type="text/css" href="css/s10.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
<br>
	
      <br><br><br>
      <center><div id="form">
        <form action="" method="post">
        <table>

    <label for="first" >Name:</label>
	<input id="first" type="text" name="name" placeholder="Name"  autofocus required />

	<br><br><br>

	<label>Date:</label>
	<input id="date" name="date" type="date" value="2021-12-27">
		 

	<br><br><br>

	<label for="first" >Email:</label>
	<input id="first" type="text" name="email" placeholder="Email"  autofocus required />

	<br><br><br>

	<label for="phone">Phone Number:</label>
	<input id="phone" type="tel" name="mno"placeholder="+8801********" required />

	<br><br><br>

	<label for="first" >Product Information:</label>
	<input id="first" type="text" name="proinfo" placeholder="Product Information"  autofocus required />

	<br><br><br>

	<label for="first" >Product ID:</label>
	<input id="first" type="text" name="proid" placeholder="Product ID"  autofocus required />

	<br><br><br>

	<label for="first" >Price:</label>
	<input id="first" type="text" name="price" placeholder="price"  autofocus required />

	<br><br><br>

	<label for="first" >Address:</label>
	<input id="first" type="text" name="address" placeholder="address"  autofocus required />

	<br><br>


	<br>
	 
	 <tr>
            <td><input type="submit" name="sub" value="Submit"></td>
          </tr>
      </table>
  </form>

</div>
    <?php
    if(isset($_POST['sub'])){
        $name=$_POST['name'];
        $date=$_POST['date'];
        $email=$_POST['email'];
        $mno=$_POST['mno'];
        $proinfo=$_POST['proinfo'];
        $proid=$_POST['proid'];
        $price=$_POST['price'];
        $address=$_POST['address'];
       
				
 $q=$db->prepare("INSERT INTO post_for_sell(name,date,email,mno,proinfo,proid,price,address) VALUES (:name, :date, :email, :mno, :proinfo, :proid,:price,:address)");

        $q->bindValue('name',$name);
        $q->bindValue('date',$date);
        $q->bindValue('email',$email);
        $q->bindValue('mno',$mno);
        $q->bindValue('proinfo',$proinfo);
        $q->bindValue('proid',$proid);
         $q->bindValue('price',$price);
        $q->bindValue('address',$address);
       

      if($q->execute())
            {
              echo "<script>alert('Posting Successfull')</script>";
            }
            else
            {
              echo "<script>alert('Posting Failed')</script>";
            }
         } 
           ?>
      </div></center>
    </div>
	

	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
			    <li><a href="admin.php">Home</a></li>
				<li><a href="delivery.php">Delivery</a></li>
				<li><a href="payment.php">Payment</a></li>
				<li><a href="refund.php">Refund Request</a></li>
				<li><a href="review.php">Review</a></li>
				<li><a href="logout.php">Logout</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>
