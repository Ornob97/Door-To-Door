<?php
include('connection.php');
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Door to Door</title>
	<img src="images/logo.png" class="logo">
	<div class="banner-text">
		<h1>Door to Door</h1>
		<p>Sign Up</p>
	<link rel="stylesheet" type="text/css" href="css/s00.css">
	<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Kalam&family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
	<br>
	
      <br><br><br>
      <center><div id="form">
        <form action="" method="post">
        <table>
         <label for="first" >First Name:</label>
	<input id="first" type="text" name="fname" placeholder="First Name"  autofocus required />

	<br><br><br><br>

	<label for="first" >Last Name:</label>
	<input id="first" type="text" name="lname" placeholder="Last Name"  autofocus required />

	<br><br><br><br>

	<label for="first" >Email:</label>
	<input id="first" type="text" name="email" placeholder="Email"  autofocus required />

	<br><br><br><br>

	<label for="first" >Password:</label>
	<input id="first" type="text" name="pass" placeholder="Password"  autofocus required />

	<br>
	

	 <tr>
            <td><input type="submit" name="sub" value="Save"></td>
          </tr>

</div>
    <?php
    if(isset($_POST['sub'])){
        $fname=$_POST['fname'];
        $lname=$_POST['lname'];
        $email=$_POST['email'];
        $pass=$_POST['pass'];
        
 $q=$db->prepare("INSERT INTO login(fname,lname,email,pass) VALUES (:fname,:lname,:email,:pass)");

        
        $q->bindValue('fname',$fname);
        $q->bindValue('lname',$lname);
        $q->bindValue('email',$email);
        $q->bindValue('pass',$pass);
      
      if($q->execute())
            {
              echo "<script>alert('Sign Up Successfull')</script>";
            }
            else
            {
              echo "<script>alert('Sign Up Fail')</script>";
            }
         } 
           ?>
      </div></center>
    </div>

	<div class="banner-btn">
	<div id="sideNav">
		<nav>
			<ul>
				<li><a href="index.php">Main Screen</a></li>
				<li><a href="login.php">Login</a></li>
				<li><a href="abt.php">About Us</a></li>
				<li><a href="contect.php">Contact</a></li>
			</ul>
		</nav>
	</div>
</div>
	<div id="menuBtn">
		<img src="images/menu.png" id="menu">
	</div>
	

<script>
		var menuBtn=document.getElementById("menuBtn")
		var sideNav=document.getElementById("sideNav")
		var menu=document.getElementById("menu")

				menuBtn.onclick=function(){
					if(sideNav.style.right=="-250px"){
						sideNav.style.right="0";
						}
					else{
						sideNav.style.right="-250px";
						
					}
}
	</script>

</body>
</html>